# Sable Calculator v100.0 — QA report

## Release scope
A new Sable-branded application shell and visual system replaces the previous SA Calculator navy/blue UI. The new product uses a warm-paper / graphite / persimmon visual language and Desk / Explore / Activity / Profile navigation. Saved tools now live inside Explore. Light, Dark and Follow device modes are functional, with six new accent palettes and a v3 migration away from the old forced-blue theme.

The previous calculator/domain engines and currency refresh/provider logic remain the compatibility core. Six new standalone calculator engines have been added in `assets/js/sable-calculators.js`: Bill Split, Compound Growth, Markup & Margin, Ratio Split, Quick Statistics and Time Span.

## Automated verification completed
- 96/96 Node tests passed.
- 9/9 JavaScript files passed `node --check`.
- CSS parser: 0 parse errors in the new canonical stylesheet.
- HTML parsed successfully; no duplicate IDs.
- 23 tool cards found and each new destination has a dedicated screen.
- Six accent palettes, three appearance modes and OLED styling are wired into the new theme token system.
- Android web bundle generated successfully; 14 required source assets verified.
- New calculator module is included in the generated bundle and service-worker precache.
- GitHub Actions YAML parsed successfully; root workflow and standalone YAML are byte-identical.
- Package, HTML, manifest and service-worker cache identity are synchronized to `2.00.0-v100.0`.
- New Sable icon artwork is present in the Android launcher icon set.
- The source ZIP is re-extracted and retested before delivery.

## Desk research
Reviewed public product information for 23 calculator products, including Google Calculator, Samsung Calculator, ClevCalc, HiPER, RealCalc, Desmos Scientific, Desmos Graphing, GeoGebra, Wolfram|Alpha, Calculator Plus, All-In-One Calculator, CalcKit, CalcKit.io, PCalc, Calzy, Soulver, Calca, MyScript Calculator 2, Mathlab, Calculator++, CALCU, Fossify Calculator and NCalc.

This was public-page desk research, not identical-device hands-on benchmarking of every product. See `RESEARCH-23-CALCULATOR-APPS-v100.0.md` for the feature signals, synthesis and source links.

## Not yet verified
- A live GitHub Actions run and actual Android APK artifact.
- Installation and use on a physical Android handset.
- Visual screenshot review across multiple Android OEMs, display densities and font scaling.
- TalkBack/manual accessibility audit.
- Sustained frame-time, memory and thermal/performance benchmarking.
- Live currency provider connectivity with the user's production API credentials.

A passing automated suite is not proof of zero defects or zero lag on every handset. These final claims require physical-device and live-service testing.
