# Sable v100.0 — calculator-app desk research and design decisions

Research date: 19 November 2026. Scope: public product descriptions, vendor documentation and app-store feature pages. This is desk research, not a claim that 23 apps were installed and benchmarked on identical devices.

## Apps reviewed (23)

| Product | Strong design/product signal considered |
|---|---|
| Google Calculator | Low-friction everyday arithmetic and uncluttered entry |
| Samsung Calculator | Clear separation of standard, engineering and history workflows |
| ClevCalc | Broad everyday utility coverage and categorized calculators |
| HiPER Scientific Calculator | Dense scientific capability, expression editing and advanced math |
| RealCalc Scientific Calculator | Familiar physical-calculator interaction and optional RPN |
| Desmos Scientific Calculator | Persistent visible expressions and answer reuse |
| Desmos Graphing Calculator | Graph-first exploration for functions |
| GeoGebra Calculator Suite | Linked algebra, graph, table and graphics views |
| Wolfram|Alpha | Knowledge-backed and stepwise mathematical exploration |
| Calculator Plus with History | Practical household and financial calculations with history |
| All-In-One Calculator | Wide calculator/converter catalog and multi-currency conversion |
| CalcKit | Search, recently used tools, favorites and offline-first utility flow |
| CalcKit.io | Fast access to a broad catalog and custom calculators |
| PCalc | Layout choice, paper tape, RPN, memory and conversion tools |
| Calzy | Memory area, bookmarks, basic/advanced modes and privacy |
| Soulver | Calculation notes with named expressions and contextual results |
| Calca | Math-document workflow with variables and reusable expressions |
| MyScript Calculator 2 | Paper-like multi-line calculation and direct manipulation |
| Mathlab Graphing Calculator | Graphing and algebra-oriented workflow |
| Calculator++ | Configurable scientific calculator and widget-style access |
| CALCU | Theme/personalization-led calculator experience |
| Fossify Calculator | Local-first privacy and minimal permission model |
| NCalc | Scientific calculator workflow and configurable math functions |

## Cross-app observations

1. **Entry speed matters:** everyday calculator screens prioritize a visible expression, a legible result and reachable numeric keys. Scientific functions should not crowd the default keypad.
2. **History is a workflow, not a dump:** reuse, copy, edit and delete actions make past calculations useful. Sable exposes this as Activity.
3. **Tools need intent-based discovery:** broad catalogs benefit from search, grouping and saved/recent shortcuts. Sable uses task groups rather than a long unstructured list.
4. **Advanced modes should be progressive:** scientific and specialist tools remain separate destinations, not a permanently dense keypad.
5. **Input/result hierarchy must survive small screens:** long expressions and large results need independent sizing and overflow control.
6. **Themes are system-wide:** surfaces, fields, keypad, navigation, status and dialogs need shared tokens, not per-screen color patches.
7. **Offline and privacy expectations should be explicit:** calculations stay local where possible; live exchange rates are a network-dependent exception.
8. **No single app should be copied:** Sable uses a new warm-paper / graphite / persimmon palette, a four-destination navigation model and its own naming/content hierarchy. The research informed general interaction principles only.

## Sable's independent design direction

- Visual identity: warm mineral paper, deep graphite, persimmon action color and a restrained sage success color.
- Primary navigation: Desk / Explore / Activity / Profile.
- Saved calculators: integrated into Explore, not a separate bottom-level destination.
- Calculator: paper-like display surface, dark tactile key field, high-contrast equals action, adaptive result sizing.
- Tool discovery: query-first library, intent categories, task descriptions and dedicated workspaces.
- Settings: one consistent field and row language, with light/dark palettes sharing the same semantic tokens.
- Responsive behavior: safe-area aware navigation, narrow-screen layout, reduced-motion support and visible focus states.

## Evidence / source pages

- Google Play: ClevCalc — https://play.google.com/store/apps/details?id=com.dencreak.dlcalculator
- Google Play: Samsung Calculator — https://play.google.com/store/apps/details?id=com.sec.android.app.popupcalculator
- Google Play: HiPER — https://play.google.com/store/apps/details?id=cz.hipercalc
- Google Play: RealCalc — https://play.google.com/store/apps/details?id=uk.co.nickfines.RealCalc
- Google Play: Desmos Scientific — https://play.google.com/store/apps/details?id=com.desmos.scientific
- GeoGebra product documentation — https://help.geogebra.org/hc/en-us/articles/10445800380957-GeoGebra-Tools-and-Features-An-Overview
- PCalc official feature page — https://pcalc.com/ios/
- Calzy App Store page — https://apps.apple.com/in/app/calzy/id623690732
- MyScript Calculator 2 — https://play.google.com/store/apps/details?id=com.myscript.calculator
- Calculator Plus — https://play.google.com/store/apps/details?id=com.digitalchemy.calculator.freedecimal
- CalcKit — https://play.google.com/store/apps/details?id=com.yasirulakmal.calckit
- CalcKit.io — https://play.google.com/store/apps/details?id=com.ivanGavrilov.CalcKit
- All-In-One Calculator — https://play.google.com/store/apps/details?id=all.in.one.calculator
- App comparison and further references — https://www.itechguides.com/10-best-calculator-apps-for-android-scientific-graphing-and-everyday-picks/
